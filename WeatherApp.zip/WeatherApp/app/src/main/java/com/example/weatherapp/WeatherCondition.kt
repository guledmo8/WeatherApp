package com.example.weatherapp

data class WeatherCondition(
    val main: String,
    val name: String,
)
